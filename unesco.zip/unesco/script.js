var btns = document.querySelectorAll('button');
var line = document.querySelector('.line');
var year = document.querySelector('.year');
var desc = document.querySelector('.description');
var card = document.querySelector('.card');


function sayWhat(e) {
  console.log(e)
}

for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener('click', function(event){
    card.style.filter = "blur(50px)"
    var multiplier = +event.target.dataset.ref;
    event.preventDefault();
    line.style.width = 200*multiplier + 'px'; 
    setTimeout(function(){ card.style.filter = "blur(0)";
                         year.innerHTML = event.target.dataset.year;
    desc.innerHTML = event.target.dataset.description;}, 250);
    
    
  })
}